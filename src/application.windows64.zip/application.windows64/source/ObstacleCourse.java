import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ObstacleCourse extends PApplet {

//ObstacleCorse Game
//By Beca Bringard

Alien s1;
ArrayList<Laser> lasers;
ArrayList<Rock> rocks;
ArrayList<Point> pts;
Timer laserTimer, puTimer, rockTimer;
int points, score, health, speed;
boolean play;

public void setup() {
  
  background (41, 0, 102);
  s1 = new Alien(0xffCB741D);
  lasers = new ArrayList();
  rocks = new ArrayList();
  pts = new ArrayList();
  laserTimer = new Timer (PApplet.parseInt(random(2000, 5000)));
  laserTimer.start();
  puTimer = new Timer(5000);
  puTimer.start();
  rockTimer = new Timer (PApplet.parseInt(random(3000, 4000)));
  rockTimer.start();
  points = 0;
  play = false;
}

public void draw() {
  if (!play) {
    startScreen();
  } else {
    background(41, 0, 102);
    
    if (laserTimer.isFinished()) {
      lasers.add(new Laser(PApplet.parseInt(random(width)), -50));
      laserTimer.start();
    }
    
    for (int i = 0; i < lasers.size(); i++) {
      Laser laser = lasers.get(i);
      laser.display();
      laser.move();
      if (s1.laserIntersection(laser)) {
        lasers.remove(laser);
        points-=laser.health;
      }
      if (laser.reachedBottom()) {
        lasers.remove(laser);
      }
    }
    
    if (rockTimer.isFinished()) {
      rocks.add(new Rock(PApplet.parseInt(random(width)), -50));
      rockTimer.start();
    }
    
    for (int i = 0; i < rocks.size(); i++) {
      Rock rock = rocks.get(i);
      rock.display();
      rock.move();
      if (s1.rockIntersection(rock)) {
        rocks.remove(rock);
        points-=rock.health;
      }
      if (rock.reachedBottom()) {
        rocks.remove(rock);
      }
    }
    
    if (puTimer.isFinished()) {
      pts.add(new Point(PApplet.parseInt(random(width)), -50));
      puTimer.start();
    }
    
    for (int i = 0; i<pts.size(); i++) {
      Point pu = pts.get(i);
      pu.move();
      pu.display();
      if (s1.puIntersection(pu)) {
        if (pu.pu == 0) {
          s1.points+=1;
        } else if (pu.pu == 1) {
          s1.points+=5;
        } else if (pu.pu == 2) {
          s1.points+=10;
        } 
        pts.remove(pu);
      }
      if (pu.reachedBottom()) {
        pts.remove(pu);
      }
    }
    
    s1.display(mouseX, mouseY);
    infoPanel();
    
    //GameOver Logic
    if (s1.points>10) {
      play = false;
      gameOver();
    }
  }
}

public void startScreen() {
  background(0, 51, 102);
  textAlign(CENTER);
  text("Welcome to the Alien Obstacle Course", width/2, height/2);
  text("Use the mouse to move your alien around the obstacles. Try to get 100 points while", width/1.78f, height/2+20);
  text("avoid the obstacles to complete the game. Obstacles will also decrease your health,", width/2, height/2+40);
  text("so try to get all the points before you die!", width/2, height/2+60);
  text("Click to countinue...", width/2, height/2+100);
  
  if (mousePressed) {
    play = true;
  }
}

public void infoPanel() {
  fill(153, 153, 255);
  rectMode(CORNER);
  rect(0, height-50, width, 50);
  text("Points" + s1.points, 50, height+20);
}

public void gameOver() {
  background(0, 51, 102);
  textAlign(CENTER);
  text("Game Over!", width/2, height/2+20);
  text("Points " + points, width/2, height/2+40);
  noLoop();
}
class Alien {
  int x, y, points, rad, health;
  int c;
  float easing;
  
  Alien(int c) {
    x = 0;
    y = 0;
    points = 0;
    this.c = c;
    easing = 0.5f;
    rad = 4;
    health = 10;
  }
  
  public boolean rockIntersection(Rock rock) {
    float distance = dist(x, y, rock.x, rock.y);
    if (distance < rad + rock.rad) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean laserIntersection(Laser laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if (distance < rad + laser.rad) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean puIntersection(Point pu) {
    float distance = dist(x, y, pu.x, pu.y);
    if (distance < rad + pu.rad) {
      return true;
    } else {
      return false;
    }
  }
  
  public void display(int x, int y) {
    this.x = x;
    this.y = y;
    ellipseMode (CENTER);
  rectMode(CENTER);
  
  //body
  stroke(0);
  fill(102, 255, 153);
  rect(x,y,20,100);
  
  //head
  stroke(0);
  fill(102, 255, 153);
  ellipse(x,y-30,60,60);
  
  //eyes
  fill(255, 153, 0);
  ellipse(x-19,y-30,16,32);
  ellipse(x+19,y-30,16,32);
  
  //legs
  stroke(0);
  line(x-10,y+50,x-20,y+60);
  line(x+10,y+50,x+20,y+60);
  
  //shirt
  stroke(0);
  fill(204, 153, 255);
  rect(x,y+15,20,30);
  }
}
class Laser {
  int x, y, speed, rad, health;
  
  Laser(int x, int y) {
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(3, 5));
    rad = 25;
    health = 10;
  }
  
  public void move() {
    y += speed;
  }
  
  public boolean reachedBottom() {
    if (y > height + 50) {
      return true;
    } else {
      return false;
    }
  }
  
  public void display() {
    noStroke();
    fill(255, 153, 255);
    rectMode(CENTER);
    rect(x, y, rad, rad*2);
  }
}
class Point {
  //member variables
  int x, y, speed, rad, pu;
  String[] puInfo = {"1", "5", "10"};

  //constructor
  Point(int x, int y) {
    rad = 80;
    this.x = x;
    this.y = y;
    speed = PApplet.parseInt(random(2, 8));
    pu = PApplet.parseInt(random(3));
  }

  public void move() {
    y += speed;
  }

  public boolean reachedBottom() {
    if (y > height + rad*4) {
      return true;
    } else {
      return false;
    }
  }

  //member methods
  public void display() {
    noStroke();
    switch(pu) {
    case 0: //1
      fill(255, 204, 102);
      ellipse(x, y, rad, rad);
      fill(0);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[0], x, y);
      break;
    case 1: //5
      fill(153, 255, 102);
      ellipse(x, y, rad, rad);
      fill(0);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[1], x, y);
      break;
    case 2: //10
      fill(51, 204, 255);
      ellipse(x, y, rad, rad);
      fill(0);
      textSize(9);
      textAlign(CENTER);
      text(puInfo[2], x, y);
      break;
    }
  }
}
class Rock {
  int x, y, speed, rad, health;
  
  Rock(int x, int y) {
    this.x = x;
    this. y = y;
    speed = 3;
    rad = 40;
    health = 10;
  }
  
  public void move() {
    y += speed;
  }
  
  public boolean reachedBottom() {
    if (y > height + 50) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean laserIntersection(Laser laser) {
    float distance = dist(x, y, laser.x, laser.y);
    if (distance < rad + laser.rad) {
      return true;
    } else {
      return false;
    }
  }
  
  public void display() {
    noStroke();
    fill(61, 61, 92);
    ellipse(x, y, rad, rad);
  }
}
// Example 10-5: Object-oriented timer
// by Daniel Shiffman

class Timer {

  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(500, 900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ObstacleCourse" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
